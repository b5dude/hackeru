// Set up Express
const express = require('express');
const router = express.Router();
router.use('/Uploads/', express.static('Uploads'));
var bodyParser = require('body-parser');
router.use(bodyParser.json({ limit: '50mb' }));
router.use(bodyParser.urlencoded({ limit: '50mb', extended: true, parameterLimit: 50000 }));

// JWT
const jwt = require('jsonwebtoken');
const jwtsecretKey = 'AudiS4B5';
const jwtExpire = {expiresIn: '1d'};

// Set up Mongoose
const schemas = require('../Schemas/schemas');

// Set up Mutler
const multer = require('multer');
const path = require('path');
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        if(req.body.userFname !== undefined){
            cb(null, './Uploads/Users_avatars');
        }

        if (req.body.commentText !== undefined) {
            cb(null, './Uploads/Comments_images');
        }

        else{
            cb(null, './Uploads/Products_files');
        }
    },
    filename: (req, file, cb) => {
        console.log(file);
        cb(null, Date.now() + '-' + file.originalname.replace(/\s/g, ""))
    }
});
const upload = multer({storage: storage});

// JWT Function
function authenticateToken(req, res, next){
    const authHeader = req.headers['authorization'];

    const token = authHeader && authHeader.split(' ')[1];

    if (!authHeader || !token) {
        return res.status(401).json({ message: 'Unauthorized' });
    }

    jwt.verify(token, jwtsecretKey, (err,user) => {
        if(err) {
            return res.status(403).json({ message: 'Forbidden' });
        }
        req.user = user;
        next();
    });
};

// All Products APIs
router.post("/get_products", (req, res) => {
    let productSearch = req.body

    switch(productSearch.type)
    {
        case "freeText":
            Product.find({productName: { "$regex": productSearch.text, "$options": "i" }}, (error, productData) => {
                if(error){
                    console.log(error);
                    res.json(error)
                }
                else{
                    res.json(productData);
                }
            })
        break;

        case "partNum":
            Product.find({productPartNumber: productSearch.text}, (error, productData) => {
                if(error){
                    res.json(error)
                }
                else{
                    res.json(productData);
                }
            }) 
        break;

        case "carModel":
            if(productSearch.fromYear === "All" && productSearch.model === ""){
                Product.find(
                    { 
                      fitCars: { 
                        $elemMatch: { 
                          selectedBrand: productSearch.brand
                        }
                      }
                    },
                    function(error, productData) {
                      if (error) {
                        res.send(error);
                      } else {
                        res.json(productData);
                      }
                    }
                );
            };
            if (productSearch.fromYear === "All" && productSearch.model !== "") {
                Product.find({
                    $or: [
                      {
                        fitCars: {
                          $elemMatch: {
                            selectedBrand: productSearch.brand,
                            selectedModel: productSearch.model
                          }
                        }
                      },
                      {
                        fitCars: {
                          $elemMatch: {
                            selectedBrand: productSearch.brand,
                            selectedModel: "",
                            selectedToYear: 0
                          }
                        }
                      }
                    ]
                  },
                  function(error, productData) {
                    if (error) {
                      res.send(error);
                    } else {
                      res.json(productData);
                    }
                  }
                );
              };
            if (productSearch.fromYear !== "All" && productSearch.brand !== "") {
                Product.find(
                  {
                    $or: [
                      {
                        fitCars: {
                          $elemMatch: {
                            selectedBrand: productSearch.brand,
                            selectedModel: productSearch.model,
                            selectedFromYear: { $lte: Number(productSearch.fromYear) },
                            selectedToYear: { $gte: Number(productSearch.fromYear) },
                          },
                        },
                      },
                      {
                        fitCars: {
                          $elemMatch: {
                            selectedBrand: productSearch.brand,
                            selectedModel: productSearch.model
                          },
                        },
                        fitCars: {
                            $elemMatch: {
                              selectedBrand: productSearch.brand,
                              selectedModel: "",
                              selectedToYear: 0 
                            },
                          },
                          fitCars: {
                            $elemMatch: {
                              selectedBrand: productSearch.brand,
                              selectedFromYear: { $lte: Number(productSearch.fromYear) },
                              selectedToYear: { $gte: Number(productSearch.fromYear) },
                            },
                          },
                      },
                    ],
                  },
                  function (error, productData) {
                    if (error) {
                      res.send(error);
                    } else {
                      res.json(productData);
                    }
                  }
                );
              }
            //   if(productSearch.fromYear !== "All" && productSearch.brand !== "" && productSearch.model === ""){
            //     Product.find(
            //         { 
            //           fitCars: { 
            //             $elemMatch: {
            //               selectedBrand: productSearch.brand
            //             }
            //           }
            //         },
            //         function(error, productData) {
            //           if (error) {
            //             res.send(error);
            //           } else {
            //             res.json(productData);
            //           }
            //         }
            //     );
            // };
        break;              

        case "new":
            Product.find({}).sort({ creationDate: -1 }).limit(3).exec((error, productData) => {
                    // console.log(productData);
                    if(error){
                        // console.log(error);
                        res.json(error)
                    }
                    else{
                        res.json(productData);
                        // console.log(productData);
                    }
                })     
            break;

            case "productId":
                Product.findOne({_id: productSearch.text}, (error, productData) => {
                    if(error){
                        res.json(error)
                    }
                    else{
                        res.json(productData);
                    }
                })        
                break;

        default:
            res.json("Not a valid search type")
        break;
    }
});

router.post("/get_authorized_products", authenticateToken, (req, res) => {
  let authorizedSroductSearch = req.body;
  let tokennUserId = req.user.user._id;
  // if (authorizedSroductSearch.text !== userId) {
  //     return res.status(403).json({ message: 'Forbidden' });
  // }

  switch(authorizedSroductSearch.type)
  {
      case "myProducts":
          Product.find({productOwner: authorizedSroductSearch.text}, (error, productData) => {
              if(error){
                  res.json(error)
              }
              else{
                  res.json(productData);
              }
          })
      break;

      case "productId":
          Product.findOne({_id: authorizedSroductSearch.text}, (error, productData) => {
              if (productData.productOwner !== tokennUserId) {
                  return res.status(403).json({ message: 'Forbidden' });
              }
              if(error){
                  res.json(error)
              }
              else{
                  res.json(productData);
              }
          })        
          break;

      default:
          res.json("Not a valid search type")
      break;
  }
});

router.post("/product_comments", authenticateToken, upload.single('commentImage'), (req, res) => {
  if (req.body.commentText !== ""){
      const newComment = req.body;
      let commentImage = '';
      if (req.file) {
          commentImage = req.file.path.replace("\\","/");
      }

      // Add the image parameter to the new comment
      newComment.commentImage = commentImage

      // Change the rate from string to Number (Due to the FormData)
      newComment.userRate = parseInt(newComment.userRate)

      Product.findOneAndUpdate({_id: newComment.productId}, 
          {$push: {productCommentsArr: newComment}}, 
          (err, result) => {
          try{
              res.status(201).json(newComment)
          }
          catch (err){
              res.status(400).json({message: err.message})
          }
          })
}});

router.post("/add_product", upload.fields([{name: 'productPictures', maxCount:6}, {name: 'productFiles', maxCount:6}]),(req, res) => {
  if (req.body.fitCars === '[]' || req.body.fitCars.length <= 2) {
      res.status(400).json({message: "Please select cars"})
      return
  }

  if (req.files.productPictures === undefined) {
      res.status(400).json({message: "Please add pictures"})
      return
  }
  
  if (req.files.productFiles == undefined) {
      res.status(400).json({message: "Please add a file"})
      return
  }

  let productPicturesArray = [];
  for (i=0; i < req.files.productPictures.length; i++){
      productPicturesArray.push(req.files.productPictures[i].path.replace("\\","/"))
  }

  let productFilessArray = [];
  for (i=0; i < req.files.productFiles.length; i++){
      productFilessArray.push(req.files.productFiles[i].path.replace("\\","/"))
  }
  
  if (req.body.productName !== "" || req.body.productOwner !== null || req.body.productCategory !== null){
      // let fitCarsArr = [];
      // for(let i=0; i < req.body.fitCars.length; i++){
      //     fitCarsArr.push(req.body.fitCars[i])
      // }
      console.log("this is what gets from the front end----------------------------------------------");
      console.log(req.body.fitCars);
      const newProductReq = new Product({
          productOwner: req.body.productOwner,
          productName: req.body.productName,
          creationDate: req.body.creationDate,
          productDescription: req.body.productDescription,
          productPartNumber: req.body.productPartNumber,
          productFiles: productFilessArray,
          productPictures: productPicturesArray,
          productCategory: req.body.productCategory,
          filamentDropDown: req.body.filamentDropDown,
          productNozzleTemp: req.body.productNozzleTemp,
          productBedTemp: req.body.productBedTemp,
          fitCars: JSON.parse(req.body.fitCars)
          // productDownloads: req.body.productDownloads,
  })

  try{
      const newProduct =  newProductReq.save()
      res.status(201).json(newProductReq)
  }
  
  catch (err) {
      res.status(400).json({message: err.message})
  }
}
});

router.post("/delete_products",  (req, res) => {
  Product.findOneAndDelete({_id: req.body.productIdToDelete}, function (err, deletedProduct) {
      console.log("Delete this " + req.body.productIdToDelete);
  if(err){
      res.status(400).json({message: err.message})
  }
  
  else {
      res.status(201).json("Product Deleted " + req.body.productIdToDelete)
  }
  }
)});

router.post("/edit_products", authenticateToken, (req, res) => {
  console.log(req.body);
  let lastUpdateDate = Date.now
  let lastUpdateDateString = lastUpdateDate.toString()

  Product.findOneAndUpdate({_id: req.body._id}, {$set:{productDescription: req.body.productDescription, productName: req.body.productName, productPartNumber: req.body.productPartNumber, productCategory: req.body.productCategory, filamentDropDown: req.body.filamentDropDown, productNozzleTemp: req.body.productNozzleTemp, productBedTemp: req.body.productBedTemp, lastUpdateDate:req.body.lastUpdateDate}}, {new: true}, (err, doc) => {
      if (err){
          // res.sendStatus(500);
          console.log("Something wrong when updating data!");
      }

      res.send('Succesfully saved');
      console.log(doc);

  })
});

router.post("/product_was_downloaded", (req, res) => {
  let counter = req.body.productDownloads
  let incrementCounter = ++counter
  Product.findOneAndUpdate({_id: req.body._id}, {$set:{productDownloads: incrementCounter}}, {new: true}, (err, doc) => {
      if (err){
          // res.sendStatus(500);
          console.log("Something wrong when updating data!");
      }

      res.json(doc)
  })
});

module.exports = router;