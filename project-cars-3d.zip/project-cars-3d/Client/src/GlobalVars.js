import { createContext } from "react";

export const userContext = createContext(null);

export const commentContext = createContext({});

export const productsContext = createContext([]);
